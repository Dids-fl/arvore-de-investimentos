# Aplicação do pacote de auditoria tributária

O ZIP é uma sobreposição cumulativa. Antes de aplicar, confirme que está na
raiz do repositório e que o trabalho local importante está commitado.

```powershell
Test-Path .git
git status --short

Expand-Archive `
  -LiteralPath .\auditoria_tributaria_profissional_v1.zip `
  -DestinationPath . `
  -Force
```

Depois execute:

```powershell
.\scripts\validar_auditoria_tributaria.ps1 -SuiteCompleta
```

Para também consultar a disponibilidade e registrar hashes atuais das páginas
oficiais, acrescente `-Online`. Essa consulta detecta indisponibilidade ou
mudança de conteúdo, mas não interpreta a legislação.

Os comandos equivalentes, caso prefira executá-los separadamente, são:

```powershell
python -m pip install --upgrade -r requirements.txt

ruff check .

python -m validacao.tributacao.validar_tudo `
  --saida .\validacao\tributacao\relatorios

python -m validacao.tributacao.auditar_fontes `
  --saida .\validacao\tributacao\relatorios\auditoria_fontes.json

python -m validacao.tributacao.reconciliar_documentos `
  .\modelos\casos_tributarios_reais_anonimizados.json `
  --saida .\validacao\tributacao\relatorios\reconciliacao_exemplo.json

python -m pytest -q tests -m "not slow" --tb=short

git diff --check
git status --short
```

Resultado de referência deste pacote:

- 63 casos;
- 21 cálculos validados;
- 5 guardrails validados;
- 34 pendências de evidência;
- 3 casos fora do escopo;
- 0 divergências;
- auditoria estrutural de fontes válida;
- 314 testes determinísticos aprovados no ambiente de construção.

Não versione documentos reais, CPF, CNPJ, nome, conta, agência ou endereço.
Use apenas dados anonimizados no modelo de reconciliação.

## O que ainda não pode ser automatizado

O pacote não autentica documentos, identidade ou inscrição profissional. Uma
revisão juridicamente responsável ainda exige advogado tributarista ou
contador habilitado, acesso à evidência original e verificação da legislação
vigente na data do fato gerador. O registro de revisão guarda a declaração e
o hash, mas não consulta OAB ou CRC.
